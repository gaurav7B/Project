
function ErrorPage(){
    return(
        <div>
            <center><h1>Page Not Founds !!! oops</h1></center>
        </div>
    )
}
export default ErrorPage;